'use client';

import React from 'react';
import OrderBlock from "@/components/blocks/OrderBlock";

export default function OrderClient() {
  return <OrderBlock />;
}