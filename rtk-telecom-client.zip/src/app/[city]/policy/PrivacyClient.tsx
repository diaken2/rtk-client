'use client';

import React from 'react';
import PrivacyContent from './PrivacyContent';

export default function PrivacyClient() {
  return <PrivacyContent />;
}